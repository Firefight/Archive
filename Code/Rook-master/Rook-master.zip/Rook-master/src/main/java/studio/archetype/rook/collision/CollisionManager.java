package studio.archetype.rook.collision;

public class CollisionManager {
}
