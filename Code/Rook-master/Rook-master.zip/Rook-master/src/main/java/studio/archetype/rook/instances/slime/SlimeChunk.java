package studio.archetype.rook.instances.slime;

public class SlimeChunk {

    public static SlimeChunk createEmpty() {
        return new SlimeChunk();
    }

    public static class Section {

    }
}
