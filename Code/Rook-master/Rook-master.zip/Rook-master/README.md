# Rook
Minestom Server Core

![NFa6OZ1EEORxrVYFF-sScg_r](https://user-images.githubusercontent.com/21113232/183261755-002109f7-9f21-4caf-aae7-a4a9451f78f1.jpg)
