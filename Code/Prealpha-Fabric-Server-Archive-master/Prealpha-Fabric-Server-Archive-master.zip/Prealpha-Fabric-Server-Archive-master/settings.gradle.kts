pluginManagement {
    repositories {
        mavenCentral()
        maven(url = "https://maven.fabricmc.net/")
        gradlePluginPortal()
    }
}
