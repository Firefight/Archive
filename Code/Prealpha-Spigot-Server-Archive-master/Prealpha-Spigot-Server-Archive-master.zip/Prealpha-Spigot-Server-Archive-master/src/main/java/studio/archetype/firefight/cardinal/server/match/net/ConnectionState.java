package studio.archetype.firefight.cardinal.server.match.net;

public enum ConnectionState {
    LOGIN,
    PLAY,
}
