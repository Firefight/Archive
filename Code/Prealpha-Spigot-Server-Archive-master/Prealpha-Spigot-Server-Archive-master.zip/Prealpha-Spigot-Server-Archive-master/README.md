<img src="https://github.com/Firefight/Cardinal/blob/master/readme.png?raw=true" align="right" width="128px" alt="Firefight Icon"/>

# Cardinal

Cardinal is Firefight's server core. It handles proxy, socket, voice sdk, raycasting, matchmaking, world management, and nomad management.

