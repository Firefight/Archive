package industries.aeternum.firefight.common.event;

public enum CommonEventHandler
{
    INSTANCE;
}
