package industries.aeternum.firefight;

public interface FFConstants
{
    String TAG_WEAPON = "Weapon";
    String TAG_FIRERATE = "WeaponFireRate";

//    String CHANNEL_SHOOT = "Firefight|Shoot";
}
