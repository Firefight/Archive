package studio.archetype.cardinal.world.slime;

public class SlimeChunk {

    public static SlimeChunk createEmpty() {
        return new SlimeChunk();
    }

    public static class Section {

    }
}
