export default {
	optifine: {
		name: 'Low Poly Guns', //'Optifine',
		recommended: true,
		enabled: true
	},

	eco: {
		name: 'sans granie', //'Eco Mode',
		enabled: false
	},

	nogc: {
		name: 'Sans Granie', //'No GC on World Change',
		enabled: true
	},

	randomcursor: {
		name: 'Randomly Moving Cursor',
		enabled: false
	}
}