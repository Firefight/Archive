# FireFight Launcher
Firefights Electron Launcher


## commands:

- `yarn start` - Starts electron
- `yarn build` - Builds main/render \[Parcel]
- `yarn dev` - Builds main/render and watches for changes of render \[Parcel]
- `yarn dist` - Builds project into dist/dist directory \[Electron Builder]


## dev

Run `dev` and then `start` in a separate terminal. 
In the future, Electron will start programmatically in development.
