# Cannelure
Firefights resource pack, adds mostly custom blocks and environment models+ textures. The name is a reference to the grooves on bullets giving them distinct levels of detail, much like a custom resource pack.


# Model Values
Every gun has its own value on the 'stick' item.
Below there is a list of all the current available weapons.


Main model: "stick"


# Assault Rifles
- Colt M16A1 	= 5
- HK XM8 		= 6
	- HK XM8 Shooting			= 7
	- HK XM8 Aiming				= 8
	- HK XM8 Aiming Shooting	= 9
	- HK XM8 Safety				= 10

# Battle Rifles
None

# Grenades
None

# Launchers
None

# Light Machine Guns
- M60E4			= 12

# Pistols
- Beretta 92FS	= 2
- AF Strike One	= 3

# Revolvers
- Colt 1873		= 4

# Shotguns
None

# Sniper Rifles
None

# Specials
- Portal Rifles	= 1

# Sub Machine Guns
- TDI Vector 	= 11
