# Firefight Firearms Index
This repository is the master working copy of all firearm assets made for and used within the world of Firefight.

The assets contained within this repository are for reference use only by the general public. Aeternum Industries grants restricted access to the public for creative and reference use only. You the public may use the assets for creative and promotive purposes only, such as for video thumbnails, or for posting during general discussion.

You do not have permission to save or modify these assets beyond the prior mentioned use. You do not have permission to include these assets in your own resource packs or modifications of the game.

If you are not sure whether your use of these assets is permitted, please reach out to us on our forum, or on discord before use. You must recieve written permission from Jonathan Aeternum in order to use these assets beyond the scope of the assets license.

Please refer to the license for official terms and permissions.
